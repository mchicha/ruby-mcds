Airbrake.configure do |config|
  config.api_key = '63bc4b1bfa2e598587583697a348f07d'
end
