set :rails_env, 'staging'
