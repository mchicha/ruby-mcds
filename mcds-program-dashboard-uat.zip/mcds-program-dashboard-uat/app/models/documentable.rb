class Documentable < ActiveRecord::Base
end
