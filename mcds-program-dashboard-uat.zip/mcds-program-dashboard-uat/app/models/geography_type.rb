class GeographyType < ActiveRecord::Base
  has_many :geographies
end
