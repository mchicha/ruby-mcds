class DeliveryMethod < ActiveRecord::Base
  has_many :programs
end
