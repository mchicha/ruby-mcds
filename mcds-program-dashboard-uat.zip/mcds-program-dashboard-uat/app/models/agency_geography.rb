class AgencyGeography < ActiveRecord::Base
end
