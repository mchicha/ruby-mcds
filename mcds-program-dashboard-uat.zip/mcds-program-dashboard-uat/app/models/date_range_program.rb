class DateRangeProgram < ActiveRecord::Base
end
