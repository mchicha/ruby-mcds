class Version < ActiveRecord::Base
end
