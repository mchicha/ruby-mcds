class Zone < ActiveRecord::Base
  has_many :documents

end
