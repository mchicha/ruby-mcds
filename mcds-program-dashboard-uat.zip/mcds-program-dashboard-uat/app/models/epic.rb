class Epic < ActiveRecord::Base
end
