class ColorBlockUser < ActiveRecord::Base
end
