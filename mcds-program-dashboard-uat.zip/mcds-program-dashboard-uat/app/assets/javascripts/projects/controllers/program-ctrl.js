angular.module('programDashboard').controller('ProgramCtrl',
  function($scope) {
    $scope.testing = "Program Dashboard";
    console.log($scope.testing);
  }
);


