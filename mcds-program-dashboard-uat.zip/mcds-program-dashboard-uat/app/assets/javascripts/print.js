//*************************************************************************
//                            SCHEMATIC APP FILES
//*************************************************************************

//= require print/app
//= require_directory "./print/controllers"
//= require_directory "./schematics/services"
//= require_directory "./print/directives"
//= require_directory "./print/templates"
//= require "./schematics/directives/adjustable"
//= require "./schematics/directives/noteable"
//= require "./schematics/directives/noteCollectable"
