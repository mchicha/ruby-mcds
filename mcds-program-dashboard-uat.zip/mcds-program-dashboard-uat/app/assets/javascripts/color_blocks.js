//= require 'color_blocks/edit_color'
//= require 'color_blocks/new_color'
//= require 'color_blocks/jquery.minicolors.min.js'
