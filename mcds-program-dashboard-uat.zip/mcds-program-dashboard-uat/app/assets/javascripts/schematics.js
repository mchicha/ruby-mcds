//*************************************************************************
//                            SCHEMATIC APP FILES
//*************************************************************************

//= require schematics/app
//= require sweet-alert.min
//= require angularjs-slider/rzslider
//= require_directory "./schematics/controllers"
//= require_directory "./schematics/services"
//= require_directory "./schematics/filters"
//= require_directory "./schematics/directives"
//= require_directory "./schematics/templates"
//= require_directory "./shared"
