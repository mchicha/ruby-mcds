class PrintsController < ApplicationController
end
