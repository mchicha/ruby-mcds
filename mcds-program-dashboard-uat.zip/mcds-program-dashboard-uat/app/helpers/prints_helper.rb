module PrintsHelper
end
