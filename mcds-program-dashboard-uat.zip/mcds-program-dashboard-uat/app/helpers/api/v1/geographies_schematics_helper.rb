module Api::V1::GeographiesSchematicsHelper
end
