Status.seed do |t|
  t.id    = 1
  t.name  = "Published"
end

Status.seed do |t|
  t.id    = 2
  t.name = "Archived"
end

Status.seed do |t|
  t.id    = 3
  t.name = "Planning"
end
