Geography.seed(:name) do |t|
  t.name = "National"
end
