DeliveryMethod.seed do |t|
  t.id    = 1
  t.name  = "UPS/FedEx"
end

DeliveryMethod.seed do |t|
  t.id   = 2
  t.name = "Distribution Center"
end
