# schematic = Schematic.find_or_create_by(name: 'Base', sch_type: 2)

# documents = Dir.glob(File.join(Rails.root,"db", "svg", "*.svg"))

# documents.each do |doc|
#   svg = Svg::Importer.new(doc)
#   svg.find_or_create
# end
