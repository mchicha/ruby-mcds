class RemoveForeignKeys < ActiveRecord::Migration
  def change
    # remove_foreign_key "documents_programs", "documents"
    # remove_foreign_key "documents_programs", "elements"
    # remove_foreign_key "documents_programs", "programs"
  end
end
