class CreateGeographiesSchematics < ActiveRecord::Migration
  def change
    # create_table :geographies_schematics do |t|

    #   t.timestamps
    # end
  end
end
