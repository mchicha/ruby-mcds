require 'rails_helper'

RSpec.describe Api::V1::LayoutsController, :type => :controller do

end
