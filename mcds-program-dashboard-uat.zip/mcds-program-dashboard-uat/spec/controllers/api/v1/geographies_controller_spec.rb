require 'rails_helper'

RSpec.describe Api::V1::GeographiesController, :type => :controller do

end
