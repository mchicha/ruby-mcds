require 'rails_helper'

RSpec.describe Api::V1::ElementsController, :type => :controller do

end
