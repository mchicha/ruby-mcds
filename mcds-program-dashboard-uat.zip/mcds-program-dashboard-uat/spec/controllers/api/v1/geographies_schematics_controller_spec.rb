require 'rails_helper'

RSpec.describe Api::V1::GeographiesSchematicsController, :type => :controller do

end
